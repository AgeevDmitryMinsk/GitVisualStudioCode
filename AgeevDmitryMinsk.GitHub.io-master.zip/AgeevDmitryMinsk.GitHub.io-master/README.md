### Pure CSS Games

для начала игры нажмите на:

## [Race 🏎](https://AgeevDmitryMinsk.github.io/)

или перейдите по ссылке:
https://AgeevDmitryMinsk.github.io/
